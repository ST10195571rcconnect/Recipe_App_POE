﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RecipeApp
{
    delegate void RecipeNotificationDelegate(Recipe recipe);

    internal class Program
    {
        private static List<Recipe> recipes = new List<Recipe>();

        public static void Main(string[] args)
        {
            try
            {
                Console.Title = "Recipe Application";

                while (true)
                {
                    Console.WriteLine("\nEnter '1' to enter a new recipe.");
                    Console.WriteLine("Enter '2' to scale a recipe.");
                    Console.WriteLine("Enter '3' to reset a recipe to its original quantities.");
                    Console.WriteLine("Enter '4' to display all recipes.");
                    Console.WriteLine("Enter '5' to exit the program.");

                    string userInput = Console.ReadLine();

                    switch (userInput)
                    {
                        case "1":
                            Recipe newRecipe = GetRecipeDetails();
                            recipes.Add(newRecipe);
                            break;
                        case "2":
                            ScaleRecipe();
                            break;
                        case "3":
                            ResetRecipeQuantities();
                            break;
                        case "4":
                            DisplayAllRecipes();
                            break;
                        case "5":
                            return;
                        default:
                            Console.ForegroundColor = ConsoleColor.Red; // Set the text color to red
                            Console.WriteLine("Invalid input. Please enter a valid option.");
                            Console.ResetColor(); // Reset the text color to the default
                            break;
                    }
                }
            }
            catch (Exception ex)
            {
                Console.ForegroundColor = ConsoleColor.Red; // Set the text color to red
                Console.WriteLine("An error occurred: " + ex.Message);
                Console.ResetColor(); // Reset the text color to the default
            }
        }


        private static Recipe GetRecipeDetails()
        {
            Console.Write("Enter the name of the recipe: ");
            string recipeName = Console.ReadLine();

            Recipe recipe = new Recipe(recipeName);

            Console.Write("Enter the number of ingredients: ");
            int numIngredients;
            if (!int.TryParse(Console.ReadLine(), out numIngredients))
            {
                Console.WriteLine("Invalid input. Number of ingredients must be an integer.");
                return null;
            }

            for (int i = 0; i < numIngredients; i++)
            {
                Console.Write($"Enter the name of ingredient {i + 1}: ");
                string ingredientName = Console.ReadLine();

                Console.Write($"Enter the quantity of {ingredientName}: ");
                double ingredientQuantity;
                if (!double.TryParse(Console.ReadLine(), out ingredientQuantity))
                {
                    Console.WriteLine("Invalid input. Quantity must be a number.");
                    return null;
                }

                Console.Write($"Enter the unit of measurement for {ingredientName}: ");
                string ingredientUnit = Console.ReadLine();

                Console.Write($"Enter the number of calories for {ingredientName}: ");
                double ingredientCalories;
                if (!double.TryParse(Console.ReadLine(), out ingredientCalories))
                {
                    Console.WriteLine("Invalid input. Calories must be a number.");
                    return null;
                }

                Console.Write($"Enter the food group for {ingredientName}: ");
                string ingredientFoodGroup = Console.ReadLine();

                Ingredient ingredient = new Ingredient(ingredientName, ingredientQuantity, ingredientUnit, ingredientCalories, ingredientFoodGroup);
                recipe.Ingredients.Add(ingredient);
            }

            return recipe;
        }

        private static void ScaleRecipe()
        {
            Console.WriteLine("\nSelect a recipe to scale:");

            for (int i = 0; i < recipes.Count; i++)
            {
                Console.WriteLine($"{i + 1}. {recipes[i].Name}");
            }

            int recipeIndex;
            if (!int.TryParse(Console.ReadLine(), out recipeIndex) || recipeIndex < 1 || recipeIndex > recipes.Count)
            {
                Console.WriteLine("Invalid recipe selection. Please try again.");
                return;
            }

            Recipe selectedRecipe = recipes[recipeIndex - 1];

            Console.WriteLine("Enter the scale factor (0.5, 2, or 3):");
            double scaleFactor;
            if (!double.TryParse(Console.ReadLine(), out scaleFactor))
            {
                Console.WriteLine("Invalid input. Scale factor must be a number.");
                return;
            }

            selectedRecipe.ScaleRecipe(scaleFactor);
        }

        private static void ResetRecipeQuantities()
        {
            Console.WriteLine("\nSelect a recipe to reset quantities:");

            for (int i = 0; i < recipes.Count; i++)
            {
                Console.WriteLine($"{i + 1}. {recipes[i].Name}");
            }

            int recipeIndex;
            if (!int.TryParse(Console.ReadLine(), out recipeIndex) || recipeIndex < 1 || recipeIndex > recipes.Count)
            {
                Console.WriteLine("Invalid recipe selection. Please try again.");
                return;
            }

            Recipe selectedRecipe = recipes[recipeIndex - 1];
            selectedRecipe.ResetQuantities();
        }

        private static void DisplayAllRecipes()
        {
            Console.WriteLine("\nAll Recipes:");

            var sortedRecipes = recipes.OrderBy(r => r.Name).ToList();

            for (int i = 0; i < sortedRecipes.Count; i++)
            {
                Console.WriteLine($"{i + 1}. {sortedRecipes[i].Name}");
            }

            Console.Write("Enter the number of the recipe you want to view: ");
            int recipeIndex = int.Parse(Console.ReadLine()) - 1;

            if (recipeIndex >= 0 && recipeIndex < sortedRecipes.Count)
            {
                Recipe selectedRecipe = sortedRecipes[recipeIndex];
                Console.WriteLine("\nSelected Recipe:");
                Console.WriteLine($"Name: {selectedRecipe.Name}");

                // Display ingredient details
                Console.WriteLine("Ingredients:");
                foreach (Ingredient ingredient in selectedRecipe.Ingredients)
                {
                    Console.WriteLine($"{ingredient.Quantity} {ingredient.Unit} {ingredient.Name}");
                    Console.WriteLine($"Calories: {ingredient.Calories}");
                    Console.WriteLine($"Food Group: {ingredient.FoodGroup}");
                }

                // Display steps
                Console.WriteLine("Steps:");
                for (int i = 0; i < selectedRecipe.Steps.Count; i++)
                {
                    Console.WriteLine($"{i + 1}. {selectedRecipe.Steps[i]}");
                }

                // Calculate total calories
                double totalCalories = selectedRecipe.CalculateTotalCalories();
                Console.WriteLine($"Total Calories: {totalCalories}");

                // Check if total calories exceed 300
                if (totalCalories > 300)
                {
                    Console.ForegroundColor = ConsoleColor.Yellow; // Set the text color to yellow
                    Console.WriteLine("Warning: Total calories exceed 300!");
                    Console.ResetColor(); // Reset the text color to the default
                }

                // Subscribe to the RecipeNotification event and provide the notification handling method
                selectedRecipe.RecipeNotification += HandleRecipeNotification;
                selectedRecipe.OnRecipeNotification();
            }
            else
            {
                Console.ForegroundColor = ConsoleColor.Red; // Set the text color to red
                Console.WriteLine("Invalid recipe number. Please try again.");
                Console.ResetColor(); // Reset the text color to the default
            }
        }

        // Method to handle the RecipeNotification event
        private static void HandleRecipeNotification(Recipe recipe)
        {
            Console.ForegroundColor = ConsoleColor.Yellow; // Set the text color to yellow
            Console.WriteLine($"Recipe '{recipe.Name}' exceeded 300 calories!");
            Console.ResetColor(); // Reset the text color to the default
        }
    }
}


