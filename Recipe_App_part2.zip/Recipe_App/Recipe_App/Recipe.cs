﻿using System;
using System.Collections.Generic;

namespace RecipeApp
{
    internal class Recipe
    {
        public string Name { get; set; }
        public List<Ingredient> Ingredients { get; set; }
        public List<string> Steps { get; set; }

        public Recipe(string name)
        {
            Name = name;
            Ingredients = new List<Ingredient>();
            Steps = new List<string>();
        }

        public void DisplayRecipeDetails()
        {
            Console.WriteLine("\nRecipe Details:");
            Console.WriteLine($"Name: {Name}");

            Console.WriteLine("Ingredients:");
            foreach (var ingredient in Ingredients)
            {
                Console.WriteLine($"{ingredient.Quantity} {ingredient.Unit} {ingredient.Name}");
            }

            Console.WriteLine("Steps:");
            for (int i = 0; i < Steps.Count; i++)
            {
                Console.WriteLine($"{i + 1}. {Steps[i]}");
            }
        }

        public void ScaleRecipe(double scaleFactor)
        {
            Console.WriteLine("\nScaled Recipe Details:");
            Console.WriteLine($"Name: {Name}");

            Console.WriteLine("Ingredients:");
            foreach (var ingredient in Ingredients)
            {
                double scaledQuantity = ingredient.Quantity * scaleFactor;
                Console.WriteLine($"{scaledQuantity} {ingredient.Unit} {ingredient.Name}");
            }

            Console.WriteLine("Steps:");
            for (int i = 0; i < Steps.Count; i++)
            {
                Console.WriteLine($"{i + 1}. {Steps[i]}");
            }
        }

        public void ResetQuantities()
        {
            Console.WriteLine("\nReset Recipe Details:");
            Console.WriteLine($"Name: {Name}");

            Console.WriteLine("Ingredients:");
            foreach (var ingredient in Ingredients)
            {
                Console.WriteLine($"{ingredient.Quantity} {ingredient.Unit} {ingredient.Name}");
            }

            Console.WriteLine("Steps:");
            for (int i = 0; i < Steps.Count; i++)
            {
                Console.WriteLine($"{i + 1}. {Steps[i]}");
            }
        }

        public event RecipeNotificationDelegate RecipeNotification;

        public double CalculateTotalCalories()
        {
            double totalCalories = 0;
            foreach (var ingredient in Ingredients)
            {
                totalCalories += ingredient.Calories;
            }
            return totalCalories;
        }

        // Method to raise the RecipeNotification event
        public virtual void OnRecipeNotification()
        {
            RecipeNotification?.Invoke(this);
        }
    }
}
